int main() {
  int x;
  for(int i : x) {
    int y = i;
  }
  return 0;
}
