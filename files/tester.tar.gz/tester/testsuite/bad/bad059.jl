// Test scope

int main() {
    int a = 5;
    return f();
}

int f() {
    return a;
}
