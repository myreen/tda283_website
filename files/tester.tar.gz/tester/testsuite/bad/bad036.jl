int if(){ return 1; }

int main() { return 1; }
