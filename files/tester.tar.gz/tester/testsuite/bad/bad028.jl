void main(){
    String x;
}
