int main() {
     int i = foo(true);
     return 0 ;
}

int foo(boolean b) { b = true; }
