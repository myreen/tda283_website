int main() {
    // Arithmetic operations with cross-types
    double x;
    double y;
    x%y;

    return 0;
}
