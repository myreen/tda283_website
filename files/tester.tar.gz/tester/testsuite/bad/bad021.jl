/* Testing that main must return. */

/* All functions should return a value of their value type. This is not a valid Javalette program: */

int main() {
}
