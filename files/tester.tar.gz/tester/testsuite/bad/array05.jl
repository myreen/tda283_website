

int main() {
  for(boolean i : new int[20]) {
    boolean x = i;
  }
  return 0;
}
