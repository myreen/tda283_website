int main() {
  1.1++; // this should only work for int
  return 1;
}
