int main() {
  int[] a;
  a = new int[50];
  a[0] = true;
  return 0;
}