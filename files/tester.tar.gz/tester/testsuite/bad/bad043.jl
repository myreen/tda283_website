int main() { 
   int else;
   return 1;
}
