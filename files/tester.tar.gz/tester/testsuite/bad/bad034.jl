int main() { 
    boolean b=true;
    while(b) return 0; 
}
