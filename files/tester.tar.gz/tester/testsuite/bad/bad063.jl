int main() {
  1; // this should be a void expression
  return 1;
}
