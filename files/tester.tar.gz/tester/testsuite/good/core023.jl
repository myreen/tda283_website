int main() { 
    if (true){}
    return 0; 
}
