int main() { 
    while(false){}
    printInt(-1);
    while(true){
          printInt(1);
          return 0;
    }
    printInt(-1);
}
